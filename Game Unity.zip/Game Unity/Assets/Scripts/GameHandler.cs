﻿/* 
This game is created by 00006878 in 26.06.2021 for refor-defor.
 */
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using CodeMonkey;
using CodeMonkey.Utils;

public class GameHandler : MonoBehaviour {

    private void Start() {
        Debug.Log("GameHandler.Start");
        Score.Start();
    }

}

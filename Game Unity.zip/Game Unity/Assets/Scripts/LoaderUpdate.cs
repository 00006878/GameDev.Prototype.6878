﻿/* 
This game is created by 00006878 in 26.06.2021 for refor-defor.
 */
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LoaderUpdate : MonoBehaviour {

    private void Update() {
        Loader.LoadTargetScene();
    }

}
